"""Poem crew template."""
